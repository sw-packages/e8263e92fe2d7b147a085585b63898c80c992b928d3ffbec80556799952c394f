//
// Copyright Aliaksei Levin (levlam@telegram.org), Arseny Smirnov (arseny30@gmail.com) 2014-2026
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//
#pragma once

#include "td/utils/common.h"

namespace td {

enum class MessageContentDupType : int32 {
  Send,            // normal message sending
  SendViaBot,      // message sending via bot
  SendQuickReply,  // quick reply sending
  Forward,         // server-side message forward
  Copy,            // local message copy
  ServerCopy       // server-side message copy
};

}  // namespace td
